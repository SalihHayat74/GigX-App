import 'package:flutter/material.dart';

const Color backgroundColors = Color(0xffFAFAFA);
const Color whiteColor = Colors.white;
const Color primaryColor = Color(0xff0D4179);
const Color backgroundColor = Color(0xff1E1E1E);
const Color subtitleColor = Color(0xffB4B4B4);
const Color buttonColors1 = Color(0xff03E5D4);
