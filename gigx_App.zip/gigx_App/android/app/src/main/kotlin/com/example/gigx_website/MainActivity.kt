package com.example.gigx_website

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
